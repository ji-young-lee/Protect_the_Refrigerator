package kr.ac.hansung.cse.service;
import kr.ac.hansung.cse.vo.MemberVO;

public interface MemberService {

	public void signup(MemberVO vo) throws Exception;
	
}
